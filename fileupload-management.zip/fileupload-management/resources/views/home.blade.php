@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <!-- Card for User's Files -->
            <div class="card shadow-sm mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ __('Your Files') }}</h5>
                    <a href="{{ route('files.create') }}" class="btn btn-primary">Upload New File</a>
                </div>

                <div class="card-body">
                    @if($files->isEmpty())
                        <div class="alert alert-info" role="alert">
                            You have no files uploaded yet.
                        </div>
                    @else
                        <!-- Display User's Files in a Table -->
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">S.No.</th>
                                    <th scope="col">File Name</th>
                                    <th scope="col">Size</th>
                                    <th scope="col">Uploaded At</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($files as $index => $file)
                                    <tr>
                                        <td>{{ $index + 1 }}</td> <!-- Serial Number -->
                                        <td>{{ $file->filename }}</td>
                                        <td>{{ round($file->size / 1024, 2) }} KB</td>
                                        <td>{{ $file->created_at->format('M d, Y H:i') }}</td>
                                        <td class="text-end">
                                            <!-- View Button -->
                                            <a href="{{ route('files.show', $file->filename) }}" class="btn btn-sm btn-info me-2">View</a>

                                            <!-- Rename Button -->
                                            <a href="{{ route('files.rename', $file->id) }}" class="btn btn-sm btn-warning me-2">Rename</a>

                                            <!-- Move Button -->
                                            <a href="{{ route('files.move', $file->id) }}" class="btn btn-sm btn-secondary me-2">Move</a>

                                            <!-- Delete Button -->
                                            <form action="{{ route('files.destroy', $file->filename) }}" method="POST" class="d-inline-block">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this file?');">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
