@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">Move File: {{ $file->name }}</div>

                <div class="card-body">
                    <form action="{{ route('files.move', $file->id) }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label for="new_name" class="form-label">New Folder Name</label>
                            <input type="text" name="new_folder" id="new_folder" class="form-control" required>
                            @error('new_folder')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-success">Move File</button>
                        <a href="{{ route('files.index') }}" class="btn btn-secondary">Cancel</a> <!-- Updated here -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

