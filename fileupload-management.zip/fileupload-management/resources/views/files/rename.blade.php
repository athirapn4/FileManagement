@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="card">
                <div class="card-header">Rename File</div>

                <div class="card-body">
                    <form action="{{ route('files.update', $file->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label for="new_name" class="form-label">New File Name</label>
                            <input type="text" name="new_name" id="new_name" class="form-control" required>
                            @error('new_name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-success">Rename</button>
                        <a href="{{ route('files.index') }}" class="btn btn-secondary">Cancel</a> <!-- Updated here -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
