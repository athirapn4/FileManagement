@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
        
            
            <div class="card shadow-sm mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ ('Your Files') }}</h5>
                    <a href="{{ route('files.create') }}" class="btn btn-primary">Upload New File</a>
                </div>

                <!-- Search Form -->
                <div class="p-3">
                    <form action="{{ route('files.search') }}" method="POST">
                        @csrf
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search files..." value="">
                            <button class="btn btn-primary" type="submit">Search</button>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    @if($userFiles->isEmpty() && $sharedFiles->isEmpty())
                        <div class="alert alert-info" role="alert">
                            You have no files uploaded yet.
                        </div>
                    @else
                      
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">S.No.</th>
                                    <th scope="col">File Name</th>
                                    <th scope="col">Uploaded At</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                @foreach ($userFiles as $index => $file)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td> 
                                        <td>{{ $file->filename }}</td>
                                        <td>{{ $file->created_at->format('M d, Y H:i') }}</td>
                                        <td class="text-end">
                                            <a href="{{ route('files.show', $file->id) }}" class="btn btn-sm btn-info me-2">View</a>
                                            <a href="{{ route('files.rename', $file->id) }}" class="btn btn-sm btn-warning me-2">Rename</a>
                                            <a href="{{ route('files.move.form', $file->id) }}" class="btn btn-sm btn-secondary me-2">Move</a>

                                           
                                            <form action="{{ route('files.destroy', $file->filename) }}" method="POST" class="d-inline-block">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this file?');">Delete</button>
                                            </form>

                                            <a href="{{ route('files.share', $file->id) }}" class="btn btn-sm btn-info">Share</a>
                                        </td>
                                    </tr>
                                @endforeach

                               
                                @foreach ($sharedFiles as $index => $file)
                                    <tr>
                                        <td>{{ $loop->iteration + $userFiles->count() }}</td> 
                                        <td>{{ $file->filename }} (Shared with you)</td>
                                        <td>{{ $file->created_at->format('M d, Y H:i') }}</td>
                                        <td class="text-end">
                                            <a href="{{ route('files.show', $file->id) }}" class="btn btn-sm btn-info me-2">View</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
