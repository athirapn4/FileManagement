<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();



Route::middleware(['auth'])->group(function () {
    Route::get('/home', [App\Http\Controllers\FileController::class, 'index'])->name('files.index');

    Route::get('/upload-file', [App\Http\Controllers\FileController::class, 'create'])->name('files.create');
    Route::post('/upload-file', [App\Http\Controllers\FileController::class, 'upload'])->name('files.upload');

    Route::get('/files/{id}/rename', [App\Http\Controllers\FileController::class, 'edit'])->name('files.rename');
    Route::put('/files/{id}/rename', [App\Http\Controllers\FileController::class, 'update'])->name('files.update');

    Route::get('/files/move/{id}', [App\Http\Controllers\FileController::class, 'showMoveForm'])->name('files.move.form');
    Route::post('/files/move/{id}', [App\Http\Controllers\FileController::class, 'move'])->name('files.move');

    Route::delete('/files/{filename}', [App\Http\Controllers\FileController::class, 'destroy'])->name('files.destroy');
    Route::get('/files/{id}', [App\Http\Controllers\FileController::class, 'show'])->name('files.show');
    Route::get('/files/{id}/share', [App\Http\Controllers\FileController::class, 'share'])->name('files.share');
    Route::post('/files/{id}/share', [App\Http\Controllers\FileController::class, 'storeShare'])->name('files.storeShare');
    Route::get('/files/shared', [App\Http\Controllers\FileController::class, 'sharedFiles'])->name('files.shared');

    Route::POST('/files/search', [App\Http\Controllers\FileController::class, 'search'])->name('files.search');

});