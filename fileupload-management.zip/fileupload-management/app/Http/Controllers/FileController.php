<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Models\File;
use App\Models\User;

class FileController extends Controller
{
   
    public function index()
    {
        $user = Auth::user();
        $userFiles = File::where('user_id', $user->id)->get();  
        $sharedFiles = Auth::user()->sharedFiles;
        return view('files.index', compact('userFiles', 'sharedFiles'));
        
    }

    public function create()
    {
        return view('files.create');
    }

   
    public function upload(Request $request)
    {
        //return $request;
        $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:5120',
        ], [
            'file.image' => 'The uploaded file must be an image.',
            'file.mimes' => 'Only jpeg, png, jpg, gif, and svg files are allowed.',
            'file.max' => 'The file size should not exceed 5MB.',
        ]);

        $user = Auth::user();
        if ($request->hasFile('file')) {
            $uploadedFile = $request->file('file');
            $imageName = time() . '-' . $uploadedFile->getClientOriginalName();
            $uploadedFile->move(public_path('storage/uploads/' . $user->id), $imageName);
            $filePath = 'storage/uploads/' . $user->id . '/' . $imageName;            
        }
        
        File::create([
            'user_id' => $user->id,
            'filename' => $imageName,
            'path' => $filePath
        ]);

        return redirect()->route('files.index')->with('status', 'File uploaded successfully!');
    }

   
    public function show($id)
    {
        $user = Auth::user();
    
        $file = File::where('files.id', $id)
                    ->where(function ($query) use ($user) {
                        $query->where('files.user_id', $user->id)
                            ->orWhereHas('sharedWith', function ($q) use ($user) {
                                $q->where('users.id', $user->id);
                            });
                    })
                    ->firstOrFail();

        $filePath = public_path($file->path);
        if (file_exists($filePath)) {
            return response()->file($filePath);
        } else {
            return redirect()->route('files.index')->with('error', 'File not found.');
        }
    }
    
    public function destroy($filename)
    {
        $user = Auth::user();
        //return $user;
        $file = File::where('user_id', $user->id)->where('filename', $filename)->firstOrFail();
        $path = public_path($file->path);

        if (file_exists($path)) {
            $file->delete(); 
            return redirect()->route('files.index')->with('success', 'File deleted successfully.');
        } else {
            return redirect()->route('files.index')->with('error', 'File not found.');
        }
    }

    public function showMoveForm($id)
    {
        $user = Auth::user();
        $file = File::where('id', $id)->where('user_id', $user->id)->firstOrFail();

        return view('files.move', compact('file'));
    }

    public function move(Request $request, $id)
    {
        $request->validate([
            'new_folder' => 'required|string|max:255',
        ]);
    
        $file = File::findOrFail($id);
        $userFolderPath = public_path('storage/uploads/');
        $newFolderName = preg_replace('/[^A-Za-z0-9_\-]/', '_', $request->input('new_folder'));
        $newFolderPath = $userFolderPath . '/' . $newFolderName;
        if (!file_exists($newFolderPath)) {
            mkdir($newFolderPath, 0777, true); 
        }
        $oldFilePath = public_path($file->path);  
        $newFilePath = $newFolderPath . '/' . $file->filename;  

       
        if (file_exists($oldFilePath)) {
           
            if (rename($oldFilePath, $newFilePath)) {
               
                $file->path = 'storage/uploads/'. $newFolderName . '/' . $file->filename;
                $file->save();

                return redirect()->route('files.index')->with('status', 'File moved successfully!');
            } else {
                return redirect()->route('files.index')->with('error', 'Failed to move file.');
            }
        } else {
            return redirect()->route('files.index')->with('error', 'File not found.');
        }
    }


    public function edit($id)
    {
        $file = File::findOrFail($id);
        return view('files.rename', compact('file'));
    }

    public function update(Request $request, $id)
    {
        //return "hi";
        $request->validate([
            'new_name' => 'required|string|max:255',
        ]);

    
        $file = File::findOrFail($id);
        $fileExtension = pathinfo($file->filename, PATHINFO_EXTENSION);

        $newFileName = preg_replace('/[^A-Za-z0-9_\-]/', '_', $request->input('new_name')) . '.' . $fileExtension;

 
        $oldpath = public_path($file->path);
        $directorypath = dirname($oldpath);
    
        $newpath = $directorypath .'/' . $newFileName;

   
        if (file_exists($oldpath)) {
        
            if (!file_exists($newpath)) {
            
                rename($oldpath, $newpath);
            } else {
                return redirect()->route('files.index')->with('error', 'A file with this name already exists.');
            }
        } else {
            return redirect()->route('files.index')->with('error', 'File not found.');
        }

    
        $file->filename = $newFileName;
        $file->path = 'storage/uploads/' . $file->user_id . '/' . $newFileName;
        $file->save();

    
        return redirect()->route('files.index')->with('status', 'File renamed successfully!');
    }
    
    public function search(Request $request)
    {
        
        $request->validate([
            'search' => 'required',
        ]);

        $user = Auth::user();
        $userFiles = File::where('user_id', $user->id)
                     ->where('filename', 'like', '%' . $request->search . '%')
                     ->get();

        $sharedFiles = Auth::user()->sharedFiles;
        return view('files.index', compact('userFiles', 'sharedFiles'));
    }

    public function share($id)
    {
        $file = File::findOrFail($id);
        $users = User::where('id', '!=', Auth::id())->get(); 
        return view('files.share', compact('file', 'users'));
    }

    public function storeShare(Request $request, $id)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
        ]);

        $file = File::findOrFail($id);
        $file->sharedWith()->attach($request->input('user_id'));

        return redirect()->route('files.index')->with('status', 'File shared successfully!');
    }
}
