<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\File;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // Fetch authenticated user's files from the database
        $user = Auth::user();
        $files = File::where('user_id', $user->id)->get();

        // Return home view with user's files
        return view('home', compact('files'));
    }
}
