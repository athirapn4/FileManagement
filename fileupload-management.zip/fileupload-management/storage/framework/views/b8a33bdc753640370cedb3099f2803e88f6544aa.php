

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
        
            
            <div class="card shadow-sm mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e(('Your Files')); ?></h5>
                    <a href="<?php echo e(route('files.create')); ?>" class="btn btn-primary">Upload New File</a>
                </div>

                <!-- Search Form -->
                <div class="p-3">
                    <form action="<?php echo e(route('files.search')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search files..." value="">
                            <button class="btn btn-primary" type="submit">Search</button>
                        </div>
                    </form>
                </div>

                <div class="card-body">
                    <?php if($userFiles->isEmpty() && $sharedFiles->isEmpty()): ?>
                        <div class="alert alert-info" role="alert">
                            You have no files uploaded yet.
                        </div>
                    <?php else: ?>
                      
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">S.No.</th>
                                    <th scope="col">File Name</th>
                                    <th scope="col">Uploaded At</th>
                                    <th scope="col" class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__currentLoopData = $userFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td> 
                                        <td><?php echo e($file->filename); ?></td>
                                        <td><?php echo e($file->created_at->format('M d, Y H:i')); ?></td>
                                        <td class="text-end">
                                            <a href="<?php echo e(route('files.show', $file->id)); ?>" class="btn btn-sm btn-info me-2">View</a>
                                            <a href="<?php echo e(route('files.rename', $file->id)); ?>" class="btn btn-sm btn-warning me-2">Rename</a>
                                            <a href="<?php echo e(route('files.move.form', $file->id)); ?>" class="btn btn-sm btn-secondary me-2">Move</a>

                                           
                                            <form action="<?php echo e(route('files.destroy', $file->filename)); ?>" method="POST" class="d-inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this file?');">Delete</button>
                                            </form>

                                            <a href="<?php echo e(route('files.share', $file->id)); ?>" class="btn btn-sm btn-info">Share</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               
                                <?php $__currentLoopData = $sharedFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration + $userFiles->count()); ?></td> 
                                        <td><?php echo e($file->filename); ?> (Shared with you)</td>
                                        <td><?php echo e($file->created_at->format('M d, Y H:i')); ?></td>
                                        <td class="text-end">
                                            <a href="<?php echo e(route('files.show', $file->id)); ?>" class="btn btn-sm btn-info me-2">View</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fileupload-management\resources\views/files/index.blade.php ENDPATH**/ ?>