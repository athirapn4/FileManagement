<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\fileupload-management\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>